<?php 
   session_start();

   /*if (!$_SESSION['queryString'])
   		header('Location: user.php');
  */
  	if (empty($_POST['searchfood']) && empty($_SESSION['searchfood'])){
   		?>
   		<script>
   	    alert("This page cannot be refreshed. Please start a new search.");
   			history.go(-1); 
   		</script>
   	<?php
   	} 

      $server_name="localhost";
      $user_name="fitfeed123_fitfeed";
      $dbpassword="fitfeed123";
      $database_name="fitfeed123_FITFEED";
      $conn = mysqli_connect($server_name,$user_name, $dbpassword,$database_name);
      if (mysqli_connect_error()){
         die("Database Connection Failed" . mysqli_connect_error());
      }
      $items = array();
      $queryString = $_SESSION['searchfood'];
     $obj = mysqli_query($conn, "SELECT * FROM Product where product_name like '%$queryString%'");
      while($row = mysqli_fetch_assoc($obj)) {
       $search_item['product_name']=$row['product_name'];
       $search_item['calories']=$row['calories'];
       $search_item['price']=$row['price'];
       $search_item['user_name']=$row['user_name'];
       $_SESSION['product_name']=$row['product_name'];
       $_SESSION['calories']=$row['calories'];
       $_SESSION['price']=$row['price'];
       $_SESSION['user_name']=$row['user_name'];

    
        array_push($items, $search_item);
      }
      
    

function placeorder()
{
        $item = $_SESSION['product_name'];
        $buyer = $_SESSION['user_name'];
        $seller = $_SESSION['user_name'];
        $status = "incomplete";
        $seen = "unseen";
        
    	$user_name="fitfeed123_fitfeed";
        $user_name="fitfeed123_fitfeed";
        $dbpassword="fitfeed123";
        $database_name="fitfeed123_FITFEED";
        $conn = mysqli_connect($server_name,$user_name, $dbpassword,$database_name);
        
        if (mysqli_connect_error()){
            die("Database Connection Failed" . mysqli_connect_error());
        }
        
        $insert = $conn->query("INSERT INTO theorder (buyer, seller, item, status, seen) VALUES ('$buyer', '$seller', '$item', '$status', '$seen')");
 //       if (!$query)
  //          echo "ERROR: " . mysqli_error($conn);
        echo "order success";
    
}

if(array_key_exists('test',$_POST)){
   placeorder();
}

?>


<!DOCTYPE html>
<html>
<head>
    <title>Fit Feed</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/lib/w3.css">
    <style>
        body {font-family: "Times New Roman", Georgia, Serif;}
        h1,h2,h3,h4,h5,h6 {
            font-family: "Playfair Display";
            letter-spacing: 5px;
        }
    </style>
    <script src="JQuery/jquery-3.1.1.min.js">
    </script>
    <script type="text/javascript">
        console.log(document.domain);
    	$(document).ready(function($){
	    var User = "<?php echo $_SESSION['name'];?>";
	    if (!User){
	        var content1 = "<a class=\"w3-bar-item w3-button\" href=\"LogIn.php\">LogIn</a>";
	        var content2 = "<a class=\"w3-bar-item w3-button w3-margin-right\" href=\"register.php\">Register</a>";
	        $("#logging").html(content1);
	        $("#register").html(content2);
	    }else{
	        var content1 = "<a class=\"w3-bar-item w3-button\" href=\"LogIn.php\">LogIn</a>";
	        var content2 = "<a class=\"w3-bar-item w3-button w3-margin-right\" href=\"register.php\">Logout</a>";
	        $("#logging").html(content1);
	        $("#register").html(content2);
	    }
	});
     </script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>JS Bin</title>
</head>

<body>
    <!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-wide w3-padding-8 w3-card-2">
    <a href="#home" class="w3-bar-item w3-button w3-margin-left">Fit Feed</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <a href="#about" class="w3-bar-item w3-button">About</a>
      <a href="#menu" class="w3-bar-item w3-button">Menu</a>
      <a href='#contact' class="w3-bar-item w3-button">Contact</a>
      <a id="logging" ></a>
      <a id="register"></a>
    </div>
  </div>
</div>


     
        <br>
        <br>
        <br>
        <br>
     
        <h2 style="background-color:#E6E6FA; text-align:center;">Here are the results we provide for you</h2>
        <br>
         <h3 style="color:#778899; text-align:center;"><?php 
         echo("---------------------------");
         echo('<br>');
         for($i=0;$i<count($items);$i++){
            echo("product:"); 
            echo($items[$i]['product_name']);
            echo '<br>';  
            echo("  calories:");
            echo($items[$i]['calories']);
            echo '<br>';  
            echo("  price:");
            echo($items[$i]['price']);
            echo '<br>';  
            echo("  sold by:");
            echo($items[$i]['user_name']);
            echo('<br>');
            echo "<input type='submit' name='test' id='test' value='placeorder'>";
            echo('<br>');
            echo("---------------------------");
            echo('<br>');
         }
      ?>
      </h3>
	   <form method="post">
   <h3 <div align="center"><input type="submit" name="test" id="test" value="placeorder"/><br/></div> </h3>
</form>
<h3 style="color:#778899; text-align:center;">
  <?php
   if($_POST["test"]=="placeorder"){echo "order success";}
?>
</h3>





</body>
</html>