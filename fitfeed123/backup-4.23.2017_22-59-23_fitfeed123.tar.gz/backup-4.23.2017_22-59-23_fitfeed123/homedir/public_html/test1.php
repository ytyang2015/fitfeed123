<head>
<!-- Start WOWSlider.com HEAD section -->
<link rel="stylesheet" type="text/css" href="engine1/style.css" />
<script type="text/javascript" src="engine1/jquery.js"></script>
</head>
<!-- End WOWSlider.com HEAD section -->
<body>
<!-- Start WOWSlider.com BODY section -->
<div id="wowslider-container1">
<div class="ws_images"><ul>
		<li><img src="data1/images/bell_pepper.jpg" alt="Bell Pepper" title="Bell Pepper" id="wows1_0"/>Peppers are rich sources of antioxidants and vitamin C</li>
		<li><img src="data1/images/fruit_bowl.jpg" alt="Fruit Bowl" title="Fruit Bowl" id="wows1_1"/>Fresh fruits are generally high in fiber, vitamin C, and water</li>
		<li><img src="data1/images/meat.jpg" alt="Meat" title="Meat" id="wows1_2"/>Meat is part of the human diet in most cultures</li>
		<li><img src="data1/images/muesli.jpg" alt="Muesli" title="Muesli" id="wows1_3"/>Muesli is a breakfast dish based on raw rolled oats and other ingredients</li>
		<li><img src="data1/images/pizza.jpg" alt="Pizza" title="Pizza" id="wows1_4"/>Pizza is topped with a selection of meats, vegetables and condiments</li>
		<li><img src="data1/images/turkey_hen.jpg" alt="Turkey Hen" title="Turkey Hen" id="wows1_5"/>Humans normally eat turkeys on special occasions such as Christmas</li>
	</ul></div>
	<div class="ws_bullets"><div>
		<a href="#" title="Bell Pepper"><span><img src="data1/tooltips/bell_pepper.jpg" alt="Bell Pepper"/>1</span></a>
		<a href="#" title="Fruit Bowl"><span><img src="data1/tooltips/fruit_bowl.jpg" alt="Fruit Bowl"/>2</span></a>
		<a href="#" title="Meat"><span><img src="data1/tooltips/meat.jpg" alt="Meat"/>3</span></a>
		<a href="#" title="Muesli"><span><img src="data1/tooltips/muesli.jpg" alt="Muesli"/>4</span></a>
		<a href="#" title="Pizza"><span><img src="data1/tooltips/pizza.jpg" alt="Pizza"/>5</span></a>
		<a href="#" title="Turkey Hen"><span><img src="data1/tooltips/turkey_hen.jpg" alt="Turkey Hen"/>6</span></a>
	</div></div>
<div class="ws_shadow"></div>
</div>	
<script type="text/javascript" src="engine1/wowslider.js"></script>
<script type="text/javascript" src="engine1/script.js"></script>
<!-- End WOWSlider.com BODY section -->
</body>
