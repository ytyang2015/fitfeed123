-- MySQL dump 10.15  Distrib 10.0.30-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: fitfeed123_FITFEED
-- ------------------------------------------------------
-- Server version	10.0.30-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Chatlog`
--

DROP TABLE IF EXISTS `Chatlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Chatlog` (
  `sender` text NOT NULL,
  `receiver` text NOT NULL,
  `log` text NOT NULL,
  `timelog` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Chatlog`
--

LOCK TABLES `Chatlog` WRITE;
/*!40000 ALTER TABLE `Chatlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `Chatlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Product`
--

DROP TABLE IF EXISTS `Product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Product` (
  `user_name` text NOT NULL,
  `product_name` varchar(60) NOT NULL,
  `price` int(11) NOT NULL,
  `calories` int(11) NOT NULL,
  `image_name` varchar(10000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Product`
--

LOCK TABLES `Product` WRITE;
/*!40000 ALTER TABLE `Product` DISABLE KEYS */;
INSERT INTO `Product` (`user_name`, `product_name`, `price`, `calories`, `image_name`) VALUES ('shabi','shit',1000,1000,''),('shabi','noodle',1000,1000,''),('restaurant1','',0,0,''),('yyt','',0,0,''),('yyt','',0,0,''),('restaurant1','',0,0,''),('restaurant1','',0,0,''),('restaurant1','',100,1000,''),('restaurant1','',100000,100,''),('restaurant1','',57,1000,''),('restaurant1','',123,123,''),('restaurant1','',0,0,''),('restaurant1','',0,0,''),('restaurant1','',0,0,''),('restaurant1','',0,0,''),('restaurant1','pasta',0,0,''),('restaurant1','',0,0,''),('restaurant1','bread',10,1000,''),('restaurant1','',0,0,''),('restaurant1','cake',20,2000,''),('restaurant1','cake',20,2000,''),('restaurant1','cake',20,2000,''),('1','Jintao',10,1000,''),('restaurant1','bread',10,1000,''),('restaurant1','bread',10,1000,''),('restaurant1','bread',10,1000,''),('restaurant1','potato salad',20,800,''),('restaurant1','411 salad',10,10,''),('restaurant2','hehe salad',1,1,''),('restaurant2','resturant2 salad',1,1,''),('restaurant2','',0,0,''),('restaurant2','testseen',1,1,''),('restaurant1','hehehehe pasta',1,1,''),('restaurant2','',0,0,''),('restaurant3','tamato salad',10,600,''),('restaurant3','tamato salad',10,600,''),('restaurant3','fried chicken',20,1000,''),('restaurant3','fried chicken',20,1000,''),('restaurant3','fried chicken',20,1000,''),('restaurant3','kentucky',5,799,''),('restaurant3','kentucky',5,799,''),('restaurant3','juice',4,200,''),('restaurant3','juice',4,200,''),('restaurant3','cake2',200,200,''),('restaurant3','cake2',200,200,''),('restaurant3','cake3',300,300,''),('restaurant3','cake3',300,300,'');
/*!40000 ALTER TABLE `Product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `article_url` text NOT NULL,
  `article_name` text NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` (`article_url`, `article_name`, `level`) VALUES ('http://www.nutritionist-resource.org.uk/articles/weight-gain.html','Weight gain\r\n',1),('http://www.medicinenet.com/script/main/art.asp?articlekey=52231','Healthy Ways to Gain Weight',1),('https://www.bodybuilding.com/content/how-to-gain-weight.html','How To Gain Weight',1),('http://well.wvu.edu/articles/help__i_m_gaining_weight','Help, I\'m Gaining Weight',1),('https://www.nhlbi.nih.gov/health/educational/lose_wt/','Maintain a Healthy Weight',2),('http://kidshealth.org/en/teens/weight-tips.html','5 Ways to Reach (and Maintain!) a Healthy Weight',2),('http://www.health.com/health/gallery/0,,20578117,00.html','Everyday Ways to Maintain Your Feel Great Weight',2),('http://www.webmd.com/diet/obesity/features/maintain-weight-loss#1','9 Secrets of Successful Weight Maintenance',2),('http://www.webmd.com/diet/features/is-fat-in-your-future#1','Is Fat in Your Future?',3),('http://therenegadepharmacist.com/lightly-cooking-foods-for-longevity/','Lightly Cooking Foods for Longevity',3),('https://www.pinterest.com/pin/58335757646935527/','Explore Lightly Slow, Cooks Lightly, and more!',3),('https://www.hsph.harvard.edu/obesity-prevention-source/obesity-causes/diet-and-weight/','Obesity Prevention Source -  Food and Eat',4),('https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3222874/','Dietary Approaches to the Treatment of Obesity',4);
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_requests`
--

DROP TABLE IF EXISTS `chat_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_requests` (
  `initiator` text NOT NULL,
  `responder` text NOT NULL,
  `url` text NOT NULL,
  `status` text NOT NULL,
  `viewed` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_requests`
--

LOCK TABLES `chat_requests` WRITE;
/*!40000 ALTER TABLE `chat_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `food`
--

DROP TABLE IF EXISTS `food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `food` (
  `name` char(255) NOT NULL,
  `user_name` char(11) NOT NULL,
  `calories` double DEFAULT NULL,
  `price` int(11) NOT NULL,
  `fat` double DEFAULT NULL,
  `carbonhydrate` double DEFAULT NULL,
  `fibrin` double DEFAULT NULL,
  `protein` double DEFAULT NULL,
  `vitunmius` double DEFAULT NULL,
  `cheese` double NOT NULL,
  `pork` double NOT NULL,
  `oil` double NOT NULL,
  `salty` double NOT NULL,
  `beef` double NOT NULL,
  `sweet` double NOT NULL,
  `chicken` double NOT NULL,
  `sour` double NOT NULL,
  `fish` double NOT NULL,
  `hot` double NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `food`
--

LOCK TABLES `food` WRITE;
/*!40000 ALTER TABLE `food` DISABLE KEYS */;
INSERT INTO `food` (`name`, `user_name`, `calories`, `price`, `fat`, `carbonhydrate`, `fibrin`, `protein`, `vitunmius`, `cheese`, `pork`, `oil`, `salty`, `beef`, `sweet`, `chicken`, `sour`, `fish`, `hot`) VALUES ('Weight Watchers Barbacoa Beef','0',144,0,3,14,0,13,0,0,0,0,1,1,0,0,14,0,3.5),('waffle','0',120,0,6,13,1,3,0,0,0,1,0,0,3.75,0,0,0,0),('Turkey Burgers with Romaine and Carrot Slaw','0',376,0,19,25,2,27,0,0,0,0,1,1,0,0,0.25,0,1.25),('Trending Articles','0',200,0,14,0,0,18,0,0,0,1,0,0,0,0,0,0,0),('Tomato soup','0',98,0,1,23,2,2,0.44,0,0,1,0.5,0,0,1,1,0,0.5),('Tofu Tostadas','0',500,0,30,6,6,6,0.12,0,0,0,0,0,0,1,0,0,0),('Tangy Chicken Salad','0',246,0,12,11,0,26,0,0,0,0.25,0,0,2,0,0,2,0),('Summer Skillet Pasta','0',541,0,31,50,3,16,0.58,2,0,0,0.5,0,0,0,5,0,0.5),('Stuffed Chicken Divan','0',347,0,11,10,1,50,0,0.5,0,0,0.5,0,0,1,0,0,0.25),('Spinach Lasagna Rolls','0',225,0,5,32,3,13,0,0.5,0,0,0,0,1.5,0,22,0,1.25),('Spinach and Feta Pasta','0',230,0,7,35,0,9,0,4,0,2,0.5,0,0,0,4.25,0,1),('Spicy Rice and Bean Wraps','0',190,0,0,40,5,8,0.14,7,0,0,0,0,0,6,1.08,0,0),('Spicy Chicken Stew','0',403,0,5,56,4,35,0,0,0,2,0,0,2.5,0.25,3.6,8,0.92),('Spaghetti','0',50,0,0,24,2,4,0,0,0,0,0.5,1,2,0,14,0,1.5),('Southwestern Cobb Salad','0',540,0,33,28,8,39,0,0.75,0,0.5,0.5,0,0.5,3,2,0,0.63),('Southern Chicken and Corn Chowder','0',280,0,18,24,0,7,0.6,0,0,0,0,0,5,32,0,0,1),('Smoked Turkey Cobb Wraps','0',640,0,0,0,0,0,0,0.75,0,0,0.5,0,0,0,0,0,0.75),('Slow Cooker Turkey Breast','0',203,0,2,32,1,17,0.18,0,0,0,1,0,1,0,1,0,0.75),('Slow Cooker Skinny White Bean Chicken Chili','0',142,0,3,9,6,12,0,0,0,0,1,0,0,1,1,0,1),('Slow Cooker Skinny Buffalo Chicken Salad','0',305,0,12,24,8,26,0,0,0,0,0,0,0,1,4,0,1),('Slow Cooker Chicken Noodle Soup','0',149,0,2,14,2,11,0,0,2,1,0,0,0,1,1,0,0.25),('Slow Cooker Chicken and Broccoli','0',226,0,6,24,2,17,0,6,0,0,0.5,0,0,1,0,0,0.75),('Slow Cooker Busy Day Stew','0',220,0,8,25,6,15,0,0,0,0,0.75,0.75,0,0,0.25,0,1.75),('Slow Cooker Black Bean and Corn Salsa Chicken','0',334,0,0,0,0,0,0,0,0,0,0.25,0,0,0,1,0,1.5),('Slow Cooker Apricot Glazed Pork Loin','0',186,0,6,8,0,23,0,0,1,0,0.5,0,0.33,0,0,0,1),('Simple Southwest Salad','0',234,0,3,33,10,20,0,0,0,0,0,1,1.5,0,1,0,0.5),('Scrambled Egg','0',365,0,27,5,0,24,0.24,0,0,1,0.25,0,0,0,0,0,0.13),('Savory Yogurt Chicken Breasts','0',402,0,19,25,1,46,0.07,1,0,0,0.13,0,0,0.5,2,0,0.33),('Sausage and Potato Bake','0',320,0,15,31,5,11,0.53,1,0,1,0.25,0,2,1,2,0,2.25),('Roman-Style Chicken','0',266,0,13,8,2,28,1.9,0,0,0,0.5,0,2,0.5,1.33,0,1.75),('Roasted Sweet Corn and Tomato Soup','0',168,0,7,24,0,8,0,0,0,1,0,0,1,14,0,0,1.63),('Roast Chicken','0',147,0,4,0,0,26,0.02,0,0,0.25,1,0,1,4,2,0,1.25),('Ricotta Stuffed Shells','0',320,0,16,27,3,17,0.25,0,0,0,0.25,0,0.75,0,1,0,0.31),('Quick Italian Turkey Soup','0',120,0,5,0,0,8,0,0,0,0,0,0,0,2,0,0,0.25),('Pita Pizza','0',140,0,8,8,0,10,0.3,4,0,0,0,0,0,0.25,0,0,0),('Pineapple Teriyaki Grilled Chicken','0',130,0,0,6,0,14,0,0,0,1,0.75,0,0,1,2,0,0.75),('Pineapple Chicken Salad Pitas','0',471,0,16,49,7,37,0,0,0,1,0.13,0,1.25,2,0,0,1),('Pickle','0',7,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0),('Petite Lasagnas','0',124,0,5,8,1,11,0,1,0,0,0.25,0,0,0,0,0,0.13),('Penne with Balsamic Chicken and Roasted Asparagus','0',255,0,9,30,0,15,0,0,0,0,0.5,0,1.5,0.5,1.2,0,0.25),('Pasta','0',45,0,0,9,1,2,0,0,0,1,0,0,1,0,0,0,1.75),('Parmesan Sesame Chicken Strips','0',1090,0,35,159,6,40,0,0,0,0,0.75,2,0,1,0,0,1),('Pancake','0',55,0,1,10,0,1,0,0,0,0,0.5,0,1.33,0,0,0,0),('Minestrone Soup','0',56,0,1,11,2,2,0,0.33,0,2,74,0,0,6,73,0,0.75),('Mexican grill','0',180,0,7,0,1,32,0.02,0,0,0,0,0,0,1,18,0,3.42),('Melt In Your Mouth Broiled Salmon','0',531,0,40,4,1,36,0.33,0,0,0,0.13,0,2,0,0,0,0),('Mediterranean Flatbread Pizzas','0',570,0,25,74,4,13,0,0,0,0,0,0,0,0,0,0,0),('Mango Quinoa Salad','0',107,0,5,15,0,2,0,0,0,0,0,0,0,0,0,0,0),('Low Fat Tex Mex Chicken and Rice','0',280,0,10,28,2,20,6.38,0.5,0,1,0,0,0,2,1,0,3.25),('Lighter Sesame Chicken','0',367,0,12,36,1,31,0,0,0,0,0,0,0,0.5,0,0,0.06),('Light Taco Casserole','0',272,0,9,26,6,20,0,2,0,0,0,0,0.13,0,3.1,0,1.63),('Light Chicken Pot Pie','0',100,0,3,15,5,4,0.15,3,0,0,0.25,0,0,3,0,0,0.38),('Kimchi','0',10,0,0,1,0,0,0.2,0,0,1,0,0,2,1,0,0,0),('Ice cream','0',145,0,8,17,1,3,0.07,8,0,0,0,0,2,0,3,0,0),('Hot pot','0',290,0,12,25,0,21,0,0,0,0,1,8,0,0,0,0,0.5),('Honey Lime Grilled Chicken','0',286,0,9,7,0,34,0,0,0,0,0,0,1.58,4,2.07,0,2),('Honey Glazed Grilled Chicken','0',284,0,6,15,0,33,0,0,0,0,0,0,2.5,0,1.2,0,0.75),('Homemade Chicken Nuggets','0',48,0,3,3,0,3,0,0,0,0,0,0,0,1,0,0,0.06),('Heavenly Halibut','0',235,0,14,1,0,26,0,0,0,1,0,0,0,0,1,0,1.19),('Healthy Southwest Stuffed Peppers','0',143,0,0,0,0,0,0,1,0,2,0.13,0,0,0,0,0,4.5),('Healthy Egg Salad Sandwich','0',300,0,0,0,0,0,0,0.5,0,0,0,0,0,0,1,0,0),('Healthy Bean Burritos','0',373,0,9,41,7,27,0,1,0,1,0.5,0,0,0,0.75,0,0.13),('Healthy Asian Glazed Drumsticks','0',213,0,5,13,0,28,0,0,0,0,0,0,0.25,2,2,2,2),('Hawaiian Grilled Chicken','0',200,0,3,14,1,30,0.06,0,0,0,0.5,0,0,4,0,0,0.25),('Guiltless Chicken Alfredo','0',280,0,12,23,0,16,5.61,0.25,0,1,0.5,0,0,1,1,0,0.5),('Grilled Ratatouille Pasta Salad','0',622,0,17,108,13,12,0,0.25,0,0.25,0.5,0,2.75,0,1.2,0,2.5),('Grilled Malibu Chicken','0',400,0,25,11,0,22,0.05,0,0,0.33,2,0,0,3,0,0,0),('Grilled Island Chicken Kabobs','0',166,0,8,2,2,16,0.04,0,0,0,0,0,0,0,0,4,0),('Grilled Honey Mustard Chicken','0',260,0,9,27,1,16,0.04,0,0,0,0,0,0,12,0,0,0.5),('Grilled Cilantro Lime Shrimp Skewers','0',350,0,16,42,2,33,0,0,0,1,0,0,0,0,0,0,1.13),('Grilled Chicken Fajita Kabobs','0',250,0,8,9,2,33,1.14,3,0,0,14,0,0,2,17,0,4),('Grilled 7-Up Chicken','0',370,0,11,12,0,28,0,0,0,0,0,0,0,2,0,0,0),('Garlic Lime Marinated Pork Chops','0',224,0,6,2,1,38,0,4,4,1,0.25,0,9,0,0,0,0.5),('Frozen yogurt','0',221,0,6,38,4,5,0.05,0,0,0,0,0,0,0,0,0,0),('Fried Chicken','0',200,0,6,21,0,17,0.14,0,0,0,0,0,1.5,2,0,0,0),('French toast','0',151,0,4,22,2,8,0.06,1,0,1,0,0,0.48,0,0.12,0,0),('Fish Taco','0',335,0,21,16,1,16,0,0,0,0,0,0,0,0,0.25,0,0),('Feta Avocado Chicken Salad','0',320,0,6,9,0,12,0,0.25,0,0,0,0,0,2,4,0,0.31),('Egg Whites and Broccoli Rice Cups','0',56,0,2,4,1,6,0.38,0,0,0,0,0,0,0,0,0,0),('Double cooked pork','0',209,0,0,0,0,0,0,0.25,6,1,0.13,0,0,0,0,0,0.5),('Crunchy Black Bean Tacos','0',400,0,20,41,7,14,0.07,0.25,0,1,0,0,0,0,1,0,0.25),('Crunchy Baked Chicken','0',457,0,23,10,0,48,0,0,0,3,1,0,2.19,1,0,0,1.06),('Crock Pot Santa Fe Chicken','0',190,0,2,23,6,21,0,0,0,0,0,0,0,1,0.75,0,0.06),('Crock Pot Beef Stew','0',499,0,11,46,7,56,0,0,0,3,0,14,0,0,1,0,0.75),('Crock Pot Asian Pork with Mushrooms','0',224,0,9,11,0,25,0,0,0,1,0,16,2,0,0,0,1.25),('Crispy Honey Mustard Chicken','0',330,0,15,34,1,14,0.02,0,0,0,0.13,0,0.75,1,0,0,1.13),('Creamy Chicken Broccoli Casserole','0',277,0,12,15,3,29,0,0.5,0,0,0,0,0,2,0,0,0.13),('Chocolate','0',534,0,30,59,3,8,0,0,0,0,0,0,12.25,0,0,0,0),('Chicken Tortilla Soup','0',200,0,15,20,3,14,0,0,0,5,0,0,0,2,22,0,4.13),('Chicken Taco','0',769,0,41,59,6,41,0.79,0,0,0,0,0,0,0,1,0,0.13),('Chicken Pot Pie Soup','0',210,0,9,20,2,13,0,0,0,0,0.5,0,0,2,0,0,0.21),('Chicken Noodle Casserole','0',200,0,8,30,1,21,0.17,0,0,1,0.5,0,0,2,8,0,2.75),('Chicken Cacciatore','0',312,0,16,7,0,35,0,0,0,2,1,0,0,1,9,0,3.5),('Chicken and Hummus Pitas','0',750,0,32,71,9,45,0,7,0,0,0,0,0,6,1.08,0,0),('Chicken and Broccolini Stir Fry','0',351,0,13,26,6,34,0,0,0,2,0,1,3,0,0,0,2.75),('Chicken and Biscuit Pot Pie','0',462,0,14,52,4,32,0.31,0.25,0,0,0,0,0.75,0.5,0,0,0.25),('Chicken and Bacon Autumn Chopped Salad','0',493,0,37,43,0,8,0,0,0,0.5,0,0,2,4,2,0,2.13),('Caribbean Salad with Sweet Orange Vinaigrette','0',281,0,10,18,4,30,0,0,0,2,0.13,0,1.75,0,0.6,0,0.38),('Cake','0',400,0,18,35,0,0,0,0,0,0.5,0.25,0,1,0,0,0,0),('Cajun Chicken Pasta','0',1270,0,60,111,6,72,0,0,0,2,0,0,0,0.75,2,0,1.75),('Buritto','0',200,0,8,35,4,9,0.18,0,0,0,0,0,0,1,0,0,0.06),('Buffalo Turkey Burgers','0',467,0,17,42,0,35,0,0,0,1,0.5,0,0,1,0,0,0.31),('Braised Balsamic Chicken','0',196,0,7,8,1,24,0.23,0,0,1,0,0,0,4,0,0,0.25),('Boiled fish','0',189,0,2,0,0,41,0.05,0,0,0,2,0,0,0,0,0,0),('Black Bean Taco Soup','0',140,0,5,19,6,6,6,0,0,0,6.5,0,0,0,0,0,1.25),('Black Bean and Sweet Potato Tostadas','0',580,0,25,79,20,19,0,0,0,0,0,0,1.75,0,1,0,3),('Bibimbap','0',563,0,15,89,0,18,0,0,0,0,0,0,0,1,0,0,0.06),('Bean and Veggie Enchilada Lasagna','0',399,0,7,67,12,16,1.23,0,0,0,0,0.5,0,0,18,0,4.13),('Balsamic Grilled Pork Chops','0',196,0,5,8,1,26,0,0,4,1,0.25,0,0,0,0,0,0.5),('Baked Turkey','0',192,0,6,0,0,32,0,1,0,0,0.5,0,0,0,0,0,0.25),('Baked Crispy Coconut Chicken with Sweet Apricot Sauce','0',523,0,10,52,3,50,0.97,0,0,2,0.5,0,2,0,0,0,0),('Baked Chicken Parmesan','0',251,0,10,14,2,32,0,0.75,0,0,0.13,0,0,0.25,0,0,0.13),('Baked Chicken Fajitas','0',348,0,12,38,3,22,0,0,0,1,0.5,0,1,4,0.5,0,1.25),('Baked Chicken Chimichangas with Green Sauce','0',303,0,12,28,0,25,0,0,1,0,0,1,0,1,0,0,4),('Baked Chicken','0',300,0,19,1,0,30,0.12,0.25,0,0,0,0,0,4,1,0,0),('Bacon','0',80,0,7,0,0,5,0,3,0,1,0,0,0,0,0,0,0),('Asian Turkey Meatballs','0',140,0,7,6,1,14,0,0,0,1,0,0,1,1,0,0,1.5),('Asian Peanut Noodles with Chicken','0',338,0,5,51,4,21,0,0,0,1,0,0,0,0,0,0,0),('Asian Chicken Lettuce Wraps','0',100,0,2,7,1,10,1.36,0,0,1,0,0,0.5,6,0,0,1.75),('Asian Chicken Burgers','0',205,0,9,9,2,19,0,0,8,0,0,1,0,0,0,0,3),('Applebee Knock-Off Oriental Chicken Salad','0',1290,0,85,84,10,51,0,0,0,1,0,0,1.5,1,0,0,1.5),('Apple Pie','0',230,0,8,37,2,2,0.16,0,0,0,0,0,1,0,0,0,0),('Apple','0',80,0,0,21,4,0,0.1,0,0,0,0,0,0,0,0,0,0),('name','0',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('Weight Watchers Salsa Roll-Ups','0',277,0,9,27,0,23,0,2,0,0,0,0,0,4,0,0,0),('yoghurt','0',49,0,2,5,0,0,0,0,0,0,0,0,0,1,0,0,0.06);
/*!40000 ALTER TABLE `food` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restaurant` (
  `name` char(255) NOT NULL,
  `category` char(255) NOT NULL,
  `address` char(255) NOT NULL,
  `phone` char(255) NOT NULL,
  `price` double NOT NULL,
  `review` int(11) NOT NULL,
  `food` char(225) NOT NULL,
  PRIMARY KEY (`food`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant`
--

LOCK TABLES `restaurant` WRITE;
/*!40000 ALTER TABLE `restaurant` DISABLE KEYS */;
INSERT INTO `restaurant` (`name`, `category`, `address`, `phone`, `price`, `review`, `food`) VALUES ('Original Pancake House','Breakfast & Brunch','1909 W Springfield Ave Champaign, IL','(217) 352-8866',20,108,'Weight Watchers Barbacoa Beef'),('Original Pancake House','Breakfast & Brunch','1909 W Springfield Ave Champaign, IL','(217) 352-8866',20,108,'waffle'),('Original Pancake House','Breakfast & Brunch','1909 W Springfield Ave\nChampaign, IL','(217) 352-8866',20,108,'Turkey Burgers with Romaine and Carrot Slaw'),('Original Pancake House','Breakfast & Brunch','1909 W Springfield Ave Champaign, IL','(217) 352-8866',20,108,'Trending Articles'),('Original Pancake House','Breakfast & Brunch','1909 W Springfield Ave Champaign, IL','(217) 352-8866',20,108,'Tomato soup'),('Original Pancake House','Breakfast & Brunch','1909 W Springfield Ave Champaign, IL','(217) 352-8866',20,108,'Tofu Tostadas'),('Original Pancake House','Breakfast & Brunch','1909 W Springfield Ave\nChampaign, IL','(217) 352-8866',20,108,'Tangy Chicken Salad'),('Original Pancake House','Breakfast & Brunch','1909 W Springfield Ave Champaign, IL','(217) 352-8866',20,108,'Summer Skillet Pasta'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Stuffed Chicken Divan'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Spinach Lasagna Rolls'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Spinach and Feta Pasta'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Spicy Rice and Bean Wraps'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Spicy Chicken Stew'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Spaghetti'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Southwestern Cobb Salad'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Southern Chicken and Corn Chowder'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Smoked Turkey Cobb Wraps'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Slow Cooker Turkey Breast'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Slow Cooker Skinny White Bean Chicken Chili'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Slow Cooker Skinny Buffalo Chicken Salad'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Slow Cooker Chicken Noodle Soup'),(' Caribbean Grill Food Truck','Caribbean, Food Trucks','Champaign, IL','(217) 960-5375',10,50,'Slow Cooker Chicken and Broccoli'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Slow Cooker Busy Day Stew'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Slow Cooker Black Bean and Corn Salsa Chicken'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Slow Cooker Apricot Glazed Pork Loin'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Simple Southwest Salad'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Scrambled Egg'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Savory Yogurt Chicken Breasts'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Sausage and Potato Bake'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Roman-Style Chicken'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Roasted Sweet Corn and Tomato Soup'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Roast Chicken'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Ricotta Stuffed Shells'),('Miga',' American (New), Asian Fusion, Desserts','301 N Neil St Ste Champaign, IL','(217) 398-1020',40,32,'Quick Italian Turkey Soup'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Pita Pizza'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Pineapple Teriyaki Grilled Chicken'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Pineapple Chicken Salad Pitas'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Pickle'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Petite Lasagnas'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Penne with Balsamic Chicken and Roasted Asparagus'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Pasta'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Parmesan Sesame Chicken Strips'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Pancake'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Minestrone Soup'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Mexican grill'),('Watson’s Shack & Rail','Bars, American (Traditional)','211 N Neil St Champaign, IL','(217) 607-0168',20,107,'Melt In Your Mouth Broiled Salmon'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Mediterranean Flatbread Pizzas'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Mango Quinoa Salad'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Low Fat Tex Mex Chicken and Rice'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Lighter Sesame Chicken'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Light Taco Casserole'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Light Chicken Pot Pie'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Kimchi'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Ice cream'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Hot pot'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Honey Lime Grilled Chicken'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Honey Glazed Grilled Chicken'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Homemade Chicken Nuggets'),('Cracked the Egg Came First','Coffee & Tea','619 E Green St Champaign, IL','(217) 372-6866',10,88,'Heavenly Halibut'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Healthy Southwest Stuffed Peppers'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Healthy Egg Salad Sandwich'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Healthy Bean Burritos'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Healthy Asian Glazed Drumstick'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Hawaiian Grilled Chicken'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Guiltless Chicken Alfredo'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Grilled Ratatouille Pasta Salad'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Grilled Malibu Chicken'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Grilled Island Chicken Kabobs'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Grilled Honey Mustard Chicken'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Grilled Cilantro Lime Shrimp Skewers'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Grilled Chicken Fajita Kabobs'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Grilled 7-Up Chicken'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Garlic Lime Marinated Pork Chops'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Frozen yogurt'),('Esquire Lounge','Pizza, Pool Halls','106 N Walnut St Champaign, IL','(217) 398-5858',10,321,'Fried Chicken'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'French toast'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'Fish Taco'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'Feta Avocado Chicken Salad'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'Egg Whites and Broccoli Rice Cups'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'Double cooked pork'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'Crunchy Black Bean Tacos'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'Crunchy Baked Chicken'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'Crock Pot Santa Fe Chicken'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'Crock Pot Beef Stew'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'Crock Pot Asian Pork with Mushrooms'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'Crispy Honey Mustard Chicken'),('Cheese and Crackers',' Chocolatiers & Shops, Delis, Seafood Markets','1715 W Kirby\nChampaign, IL','(217) 615-8531',20,52,'Creamy Chicken Broccoli Casserole'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Chocolate'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Chicken Tortilla Soup'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Chicken Taco'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Chicken Pot Pie Soup'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Chicken Noodle Casserole'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Chicken Cacciatore'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Chicken and Hummus Pitas'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Chicken and Broccolini Stir Fry'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Chicken and Biscuit Pot Pie'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Chicken and Bacon Autumn Chopped Salad'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Caribbean Salad with Sweet Orange Vinaigrette'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Cake'),('Black Dog Smoke & Ale House','Barbeque, Bars','320 N Chestnut St Champaign, IL','(217) 344-9334',20,77,'Cajun Chicken Pasta'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Buritto'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Buffalo Turkey Burgers'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Braised Balsamic Chicken'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Boiled fish'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Black Bean Taco Soup'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Black Bean and Sweet Potato Tostadas'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Bibimbap'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Bean and Veggie Enchilada Lasagna'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Balsamic Grilled Pork Chops'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Baked Turkey'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Baked Crispy Coconut Chicken with Sweet Apricot Sauce'),('Dos Reales','Mexican','1407 N Prospect Ave Champaign, IL','(217) 351-6879',10,211,'Baked Chicken Parmesan'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Baked Chicken Fajitas'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Baked Chicken Chimichangas with Green Sauce'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Baked Chicken'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Bacon'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Asian Turkey Meatballs'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Asian Peanut Noodles with Chicken'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Asian Chicken Lettuce Wraps'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Asian Chicken Burgers'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Applebee Knock-Off Oriental Chicken Salad'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Apple Pie'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Apple'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'name'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'Weight Watchers Salsa Roll-Ups'),('Peking Garden Restaurant','Chinese','206 N Randolph St Champaign, IL','(217) 355-8888',20,123,'yoghurt'),('restaurant1','bakery','123','123455',5.5,11,'bakery'),('restaurant1','bakery','123','123455',5.5,11,'bakery1');
/*!40000 ALTER TABLE `restaurant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s_chat_messages`
--

DROP TABLE IF EXISTS `s_chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `s_chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(255) NOT NULL,
  `message` varchar(255) NOT NULL,
  `when` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s_chat_messages`
--

LOCK TABLES `s_chat_messages` WRITE;
/*!40000 ALTER TABLE `s_chat_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `s_chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theorder`
--

DROP TABLE IF EXISTS `theorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `theorder` (
  `buyer` varchar(255) NOT NULL,
  `seller` varchar(255) NOT NULL,
  `item` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `seen` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theorder`
--

LOCK TABLES `theorder` WRITE;
/*!40000 ALTER TABLE `theorder` DISABLE KEYS */;
INSERT INTO `theorder` (`buyer`, `seller`, `item`, `status`, `seen`) VALUES ('shit','shit','shit','incomplete',''),('shit','shit','shit','incomplete',''),('shit','shit','shit','incomplete',''),('','','','incomplete',''),('','','','incomplete',''),('','','','incomplete',''),('','','','incomplete',''),('shabi','shabi','shit','incomplete',''),('shabi','shabi','shit','incomplete',''),('shabi','shabi','shit','incomplete',''),('restaurant1','restaurant1','potato salad','incomplete',''),('restaurant1','restaurant1','411 salad','incomplete',''),('restaurant1','restaurant1','potato salad','incomplete',''),('restaurant2','restaurant2','hehe salad','incomplete','seen'),('restaurant2','restaurant2','resturant2 salad','incomplete','seen'),('restaurant2','restaurant2','testseen','incomplete','seen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','potato salad','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant3','restaurant3','fried chicken','complete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant3','restaurant3','fried chicken','complete','unseen'),('restaurant3','restaurant3','fried chicken','complete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant1','restaurant1','hehehehe pasta','incomplete','unseen'),('restaurant3','restaurant3','tamato salad','complete','seen');
/*!40000 ALTER TABLE `theorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `username` varchar(60) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL,
  `type` varchar(1) NOT NULL DEFAULT 'C',
  PRIMARY KEY (`username`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`username`, `password`, `type`) VALUES ('xl2','123','C'),('a4','123','C'),('a5','123','C'),('rhett','123456','C'),('hahaha','123456','C'),('lilili','123','C'),('abcd','123','C'),('test','123','R'),('xuli','123','R'),('111','11','C'),('321','321','C'),('1111','1234','C'),('rrrrrr','123456','C'),('yty','hahahaha','C'),('yyt','lol','C'),('feitianjitui','111111','C'),('panera','123','R'),('iiiiii','123456','C'),('feitianjitui3','123456','C'),('llll','123','C'),('restaurant1','123456','R'),('1','1','R'),('restaurant2','123456','R'),('tangwangchao','123','R'),('restaurant3','123456','R');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_food`
--

DROP TABLE IF EXISTS `user_food`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_food` (
  `username` char(100) NOT NULL,
  `foodname` char(100) NOT NULL DEFAULT '',
  `oder` int(11) NOT NULL,
  PRIMARY KEY (`username`,`foodname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_food`
--

LOCK TABLES `user_food` WRITE;
/*!40000 ALTER TABLE `user_food` DISABLE KEYS */;
INSERT INTO `user_food` (`username`, `foodname`, `oder`) VALUES ('xl2','Chicken Noodle Casserole',11),('xl2','Chicken Tortilla Soup',10),('xl2','Ice cream',9),('xl2','Mexican grill',8),('xl2','Spaghetti',7),('xl2','Spicy Rice and Bean Wraps',6),('xl2','Tomato soup',5),('xl2','Weight Watchers Barbacoa Beef',4),('xl2','Slow Cooker Chicken Noodle Soup',2),('xl2','Pineapple Teriyaki Grilled Chicken',1),('xl2','Crock Pot Santa Fe Chicken',0),('feitianjitui3','Chicken Noodle Casserole',13),('feitianjitui3','Chicken Tortilla Soup',12),('feitianjitui3','Ice cream',11),('feitianjitui3','Mexican grill',10),('feitianjitui3','Spaghetti',9),('feitianjitui3','Spicy Rice and Bean Wraps',8),('feitianjitui3','Spinach and Feta Pasta',7),('feitianjitui3','Spinach Lasagna Rolls',6),('rrrrrr','Baked Turkey',5),('rrrrrr','Black Bean Taco Soup',4),('yyt','Pickle',3),('yyt','name',9),('yyt','Apple',8),('yyt','Bacon',7),('yyt','Egg Whites and Broccoli Rice Cups',6),('yyt','Mango Quinoa Salad',4),('yyt','Pita Pizza',2),('yyt','Trending Articles',1),('yyt','Grilled Island Chicken Kabobs',0),('yyt','Frozen yogurt',5),('feitianjitui3','Tomato soup',5),('feitianjitui3','Weight Watchers Barbacoa Beef',4),('feitianjitui3','Slow Cooker Chicken Noodle Soup',2),('feitianjitui3','Pineapple Teriyaki Grilled Chicken',1),('feitianjitui3','Crock Pot Santa Fe Chicken',0),('rrrrrr','Boiled fish',3),('rrrrrr','Chicken Pot Pie Soup',2),('rrrrrr','Hawaiian Grilled Chicken',0),('rrrrrr','Petite Lasagnas',1);
/*!40000 ALTER TABLE `user_food` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_info` (
  `username` varchar(60) NOT NULL,
  `age` int(11) NOT NULL,
  `height` double NOT NULL,
  `weight` double NOT NULL,
  `gender` char(64) NOT NULL,
  `activitylevel` int(1) NOT NULL,
  `calories` double NOT NULL,
  `sweet` int(11) DEFAULT NULL,
  `sour` int(11) NOT NULL,
  `hot` int(11) NOT NULL,
  `salty` int(11) NOT NULL,
  `Food` char(255) NOT NULL,
  PRIMARY KEY (`username`),
  FULLTEXT KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_info`
--

LOCK TABLES `user_info` WRITE;
/*!40000 ALTER TABLE `user_info` DISABLE KEYS */;
INSERT INTO `user_info` (`username`, `age`, `height`, `weight`, `gender`, `activitylevel`, `calories`, `sweet`, `sour`, `hot`, `salty`, `Food`) VALUES ('1',23,173,150,'m',0,0,NULL,0,0,0,''),('a2',28,174,150,'m',0,0,NULL,0,0,0,''),('a3',21,160,100,'f',0,0,NULL,0,0,0,''),('a4',30,180,190,'m',0,0,NULL,0,0,0,''),('a5',45,163,120,'f',0,0,NULL,0,0,0,''),('rhett',20,200,150,'f',0,0,NULL,0,0,0,''),('lilili',23,120,130,'f',0,0,NULL,0,0,0,''),('hahaha',25,165,100,'f',0,0,NULL,0,0,0,''),('test1',23,160,100,'f',0,0,NULL,0,0,0,''),('test2',23,175,140,'m',0,0,NULL,0,0,0,''),('111',21,185,72,'f',0,0,NULL,0,0,0,''),('xl2',24,174,75,'male',0,200,9,35,26,4,'beef'),('yty',20,172,55,'f',3,0,NULL,0,0,0,''),('rrrrrr',22,180,80,'f',1,248.6,NULL,2,1,23,''),('yyt',20,172,50,'f',4,276.9,NULL,0,0,0,''),('iiiiii',20,180,80,'f',1,0,NULL,0,0,0,''),('feitianjitui3',18,185,66,'f',1,237.9,NULL,1,0,0,''),('llll',20,175,80,'f',4,5000,NULL,0,0,0,'');
/*!40000 ALTER TABLE `user_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_order`
--

DROP TABLE IF EXISTS `user_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_order` (
  `username` char(255) NOT NULL,
  `orderNum` int(11) NOT NULL,
  PRIMARY KEY (`username`,`orderNum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_order`
--

LOCK TABLES `user_order` WRITE;
/*!40000 ALTER TABLE `user_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'fitfeed123_FITFEED'
--

--
-- Dumping routines for database 'fitfeed123_FITFEED'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-23 22:59:28
